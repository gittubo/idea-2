import { useEffect, useRef, useState } from 'react'
import { searchCities, getWeather, getPhotos } from './api.js'
import { loadImage, extractPalette } from './palette.js'
import { buildPacking, colorNotes } from './packing.js'

const ACTIVITIES = ['hiking', 'safari', 'beach', 'city', 'snow']
const dstr = d => d.toISOString().slice(0, 10)
const fmt = s => new Date(s + 'T00:00:00').toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })

export default function App() {
  const today = new Date()
  const in90 = new Date(today.getTime() + 90 * 86400000)
  const [query, setQuery] = useState('')
  const [options, setOptions] = useState([])
  const [place, setPlace] = useState(null)
  const [start, setStart] = useState(dstr(in90))
  const [end, setEnd] = useState(dstr(new Date(in90.getTime() + 9 * 86400000)))
  const [acts, setActs] = useState([])
  const [state, setState] = useState('idle') // idle | loading | ready | error
  const [weather, setWeather] = useState(null)
  const [photos, setPhotos] = useState([])
  const [palettes, setPalettes] = useState([])
  const [photoIx, setPhotoIx] = useState(0)
  const [packing, setPacking] = useState(null)
  const debounce = useRef(null)

  useEffect(() => {
    if (place && query === label(place)) return
    clearTimeout(debounce.current)
    debounce.current = setTimeout(async () => {
      try { setOptions(await searchCities(query)) } catch { setOptions([]) }
    }, 250)
    return () => clearTimeout(debounce.current)
  }, [query])

  const label = c => `${c.name}, ${c.country}`

  async function plan() {
    if (!place || !start || !end || new Date(end) < new Date(start)) return
    setState('loading'); setPhotos([]); setPalettes([]); setPhotoIx(0)
    try {
      const days = Math.round((new Date(end) - new Date(start)) / 86400000) + 1
      const [w, ph] = await Promise.all([
        getWeather(place.lat, place.lon, start, end),
        getPhotos(label(place))
      ])
      setWeather(w)
      setPacking(buildPacking({ days, weather: w, activities: acts }))
      setPhotos(ph)
      const pals = await Promise.all(ph.map(async p => {
        try { return extractPalette(await loadImage(p.url)) } catch { return null }
      }))
      setPalettes(pals)
      setState('ready')
    } catch (e) {
      console.error(e)
      setState('error')
    }
  }

  const palette = palettes[photoIx] || palettes.find(Boolean) || []
  const notes = colorNotes(palette, acts)
  const tripDays = start && end ? Math.round((new Date(end) - new Date(start)) / 86400000) + 1 : 0

  return (
    <div className="wrap">
      <header>
        <div className="brand">Trip Palette</div>
        <div className="tagline">pack to match your destination</div>
      </header>

      <section className="card inputs">
        <div className="field grow">
          <label>Destination</label>
          <input
            value={query}
            placeholder="City, Country"
            onChange={e => { setQuery(e.target.value); setPlace(null) }}
          />
          {options.length > 0 && !place && (
            <div className="dropdown">
              {options.map((c, i) => (
                <button key={i} onClick={() => { setPlace(c); setQuery(label(c)); setOptions([]) }}>
                  {c.name}<span>{[c.admin, c.country].filter(Boolean).join(', ')}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="field">
          <label>From</label>
          <input type="date" value={start} onChange={e => setStart(e.target.value)} />
        </div>
        <div className="field">
          <label>To</label>
          <input type="date" value={end} onChange={e => setEnd(e.target.value)} />
        </div>
        <div className="field acts">
          <label>Activities (optional)</label>
          <div className="chips">
            {ACTIVITIES.map(a => (
              <button
                key={a}
                className={acts.includes(a) ? 'chip on' : 'chip'}
                onClick={() => setActs(x => x.includes(a) ? x.filter(v => v !== a) : [...x, a])}
              >{a}</button>
            ))}
          </div>
        </div>
        <button className="go" disabled={!place || state === 'loading'} onClick={plan}>
          {state === 'loading' ? 'packing…' : 'Build my palette'}
        </button>
      </section>

      {state === 'error' && (
        <section className="card"><p className="err">That one didn't load. Check the destination and dates, then try again.</p></section>
      )}

      {state === 'ready' && weather && packing && (
        <>
          <section className="card pass">
            <div className="pass-head">
              <div>
                <div className="pass-dest">{place.name}</div>
                <div className="pass-sub">{place.country} · {fmt(start)} to {fmt(end)} · {tripDays} days</div>
              </div>
              <div className="pass-temp">
                {Math.round(packing.coldest)}°–{Math.round(packing.warmest)}°C
              </div>
            </div>
            {weather.typical && (
              <div className="typical">Typical weather for these dates (your trip is past the 16-day forecast window, so this is the same dates last year)</div>
            )}
            <div className="weather-strip">
              {weather.days.slice(0, 14).map((d, i) => (
                <div className="wday" key={i}>
                  <div className="wdate">{fmt(d.date)}</div>
                  <div className="wtemp">{Math.round(d.tmax)}°</div>
                  <div className="wmin">{Math.round(d.tmin)}°</div>
                  <div className="wrain">{weather.typical ? ((d.rainMm || 0) >= 2 ? '🌧' : '·') : ((d.rainPct || 0) >= 40 ? '🌧' : '·')}</div>
                </div>
              ))}
            </div>
          </section>

          {photos.length > 0 && (
            <section className="card">
              <h2>The landscape, the palette</h2>
              <div className="photo-box">
                <img src={photos[photoIx].url} alt={place.name} crossOrigin="anonymous" />
                <div className="credit">photo: <a href={photos[photoIx].page} target="_blank" rel="noreferrer">{photos[photoIx].credit || 'Wikimedia Commons'}</a></div>
              </div>
              {photos.length > 1 && (
                <div className="thumbs">
                  {photos.map((p, i) => (
                    <button key={i} className={i === photoIx ? 'thumb on' : 'thumb'} onClick={() => setPhotoIx(i)}>
                      <img src={p.url} alt="" crossOrigin="anonymous" />
                    </button>
                  ))}
                </div>
              )}
              {palette.length > 0 && (
                <div className="swatches">
                  {palette.map((h, i) => (
                    <div className="swatch" key={i}>
                      <div className="chipcolor" style={{ background: h }} />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              )}
              {notes && (
                <div className="notes">
                  <strong>What to actually wear:</strong> {notes.why}
                </div>
              )}
            </section>
          )}

          <section className="card">
            <h2>The packing list</h2>
            <div className="tier">{packing.tier}</div>
            <ul className="list">
              {packing.items.map((it, i) => (
                <li key={i}>
                  <span className="qty">{it.qty}</span>
                  <span className="name">{it.name}</span>
                  <span className="why">{it.why}</span>
                </li>
              ))}
            </ul>
          </section>
        </>
      )}

      <footer>
        built with Claude by <a href="https://instagram.com/cindiezhu" target="_blank" rel="noreferrer">@cindiezhu</a> · weather by <a href="https://open-meteo.com" target="_blank" rel="noreferrer">Open-Meteo</a> · photos from Wikimedia Commons
      </footer>
    </div>
  )
}
