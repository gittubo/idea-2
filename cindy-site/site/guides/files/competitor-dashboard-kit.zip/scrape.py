#!/usr/bin/env python3
"""Competitor dashboard scraper (@cindiezhu edition).

One job: pull your competitors' latest reels WITH transcripts and stage
them as a batch for Claude to analyze. The thinking (scoring, breakdowns,
the dashboard itself) happens in your Claude session, see ANALYZE.md and
DASHBOARD-SPEC.md.

One API key. No video downloads. Apify's Instagram reel scraper has a
built-in transcript add-on, so there is no second transcription service
to sign up for and no video files to clean up afterwards.

Setup:
    pip install requests
    Put your key in a .env file next to this script (Claude can do this):
        APIFY_TOKEN=your-apify-token
    (An APIFY_TOKEN environment variable works too.)

Run:
    python3 scrape.py                  # 3 latest reels per active account
    python3 scrape.py --limit 5        # 5 per account
    python3 scrape.py --accounts some_handle another_handle
    python3 scrape.py --balance        # print Apify usage/credit and exit
"""
from __future__ import annotations
import argparse, datetime, json, os, re, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ACCOUNTS_MD = ROOT / "competitor-accounts.md"
NOTES_DIR = ROOT / "notes"        # Claude writes one note per keeper here
LEDGER = ROOT / "ledger.json"     # dedup memory, you only pay for NEW reels
STAGING = ROOT / "staging"
APIFY_ACTOR = "xMc5Ga1oCONPmWJIa" # Apify's official Instagram Reel Scraper

try:
    import requests
except ImportError:
    sys.exit("The 'requests' package is missing. Run: pip install requests")


def load_token() -> str:
    """APIFY_TOKEN from the environment, or from a .env file next to this
    script. Keep the key in .env (gitignored), not in your shell profile."""
    val = os.environ.get("APIFY_TOKEN", "").strip()
    if not val:
        env_file = ROOT / ".env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                if line.strip().startswith("APIFY_TOKEN"):
                    val = line.split("=", 1)[-1].strip().strip('"').strip("'")
    if not val:
        sys.exit("APIFY_TOKEN not set. Get it at apify.com -> Settings -> "
                 "Integrations, then put APIFY_TOKEN=... in a .env file "
                 "next to scrape.py")
    return val


def with_retry(fn, *, what: str, attempts: int = 3, base_delay: float = 2.0):
    """Retry transient failures with backoff so one network blip doesn't
    kill the run. Re-raises the last error after the final attempt."""
    last_exc = None
    for attempt in range(1, attempts + 1):
        try:
            return fn()
        except Exception as e:
            last_exc = e
            if attempt == attempts:
                break
            delay = base_delay * (2 ** (attempt - 1))
            print(f"  {what} failed (attempt {attempt}/{attempts}): {e}, retrying in {delay:.0f}s")
            time.sleep(delay)
    raise last_exc


def write_json(path: Path, data, **dump_kw):
    """Atomic write, so a crash mid-write can't corrupt the ledger/batch."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, **dump_kw))
    tmp.replace(path)


def active_accounts() -> list[str]:
    if not ACCOUNTS_MD.exists():
        sys.exit(f"{ACCOUNTS_MD.name} not found. Fill in the template first.")
    users = []
    for line in ACCOUNTS_MD.read_text().splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 2:
            continue
        user, active = cells[0].lstrip("@"), cells[-1].lower()
        if user.lower() in ("username", "") or "---" in user:
            continue
        if active == "yes":
            users.append(user)
    if not users:
        sys.exit("No rows with Active = yes in competitor-accounts.md")
    return users


def shortcode_from_url(url: str) -> str:
    m = re.search(r"/(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url or "")
    return m.group(1) if m else (re.sub(r"[^A-Za-z0-9_-]", "", (url or ""))[-11:] or "unknown")


def load_ledger() -> dict:
    if LEDGER.exists():
        return json.loads(LEDGER.read_text())
    return {"processed": [], "low_score": [], "scraped": []}


def existing_shortcodes() -> set[str]:
    codes = set()
    if NOTES_DIR.exists():
        for f in NOTES_DIR.rglob("SCRAPED-*.md"):
            m = re.search(r"source_url:\s*(\S+)", f.read_text())
            if m:
                codes.add(shortcode_from_url(m.group(1)))
    return codes


def run_apify(token: str, usernames: list[str], per_account: int) -> list[dict]:
    url = f"https://api.apify.com/v2/acts/{APIFY_ACTOR}/run-sync-get-dataset-items"
    body = {
        "username": usernames,
        "resultsLimit": per_account,
        "includeTranscript": True,   # the add-on that replaces a whole second API
        "skipPinnedPosts": True,     # pinned reels are usually old winners you've seen
    }

    def _call():
        r = requests.post(url, json=body,
                          headers={"Authorization": f"Bearer {token}",
                                   "Accept": "application/json"},
                          timeout=600)
        r.raise_for_status()
        return r.json()
    return with_retry(_call, what="Apify run")


def print_balance(token: str):
    def _call():
        r = requests.get("https://api.apify.com/v2/users/me/limits",
                         headers={"Authorization": f"Bearer {token}"}, timeout=60)
        r.raise_for_status()
        return r.json().get("data", {})
    d = with_retry(_call, what="Apify usage")
    cur, lim = d.get("current", {}), d.get("limits", {})
    used, cap = cur.get("monthlyUsageUsd"), lim.get("maxMonthlyUsageUsd")
    print("Apify usage this cycle:")
    if used is not None and cap is not None:
        print(f"  ${used:.2f} / ${cap:.2f} used   (~${cap - used:.2f} left)")
    print(f"  cycle resets: {d.get('monthlyUsageCycle', {}).get('endAt', '?')}")


def field(item: dict, *names, default=None):
    for n in names:
        if item.get(n) not in (None, ""):
            return item[n]
    return default


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=3, help="reels per account")
    ap.add_argument("--accounts", nargs="*", help="override the account list")
    ap.add_argument("--cap", type=int, default=50, help="max new reels per run")
    ap.add_argument("--balance", action="store_true", help="print Apify usage and exit")
    args = ap.parse_args()

    token = load_token()
    if args.balance:
        print_balance(token)
        return

    STAGING.mkdir(exist_ok=True)
    NOTES_DIR.mkdir(exist_ok=True)
    accounts = args.accounts or active_accounts()
    print(f"accounts ({len(accounts)}): {', '.join(accounts)}  |  {args.limit}/account")

    ledger = load_ledger()
    seen = set(ledger["processed"]) | set(ledger["low_score"]) | set(ledger["scraped"]) | existing_shortcodes()
    print(f"dedup set: {len(seen)} known shortcodes")

    print("calling Apify (scrape + transcript in one pass)...")
    items = run_apify(token, accounts, args.limit)
    print(f"  Apify returned {len(items)} items")

    batch, new = [], 0
    for it in items:
        if new >= args.cap:
            print(f"  hit --cap {args.cap}, the rest stays for next run")
            break
        url = field(it, "url", "postUrl", default="")
        code = shortcode_from_url(url)
        if code in seen:
            continue
        user = field(it, "ownerUsername", "username", default="unknown")
        transcript = (field(it, "transcript", default="") or "").strip()
        if not transcript:
            print(f"  [{user}] {code} (no transcript, probably music-only; staging anyway)")
        else:
            print(f"  [{user}] {code}")
        batch.append({
            "shortcode": code,
            "username": user,
            "url": url,
            "views": field(it, "videoPlayCount", "videoViewCount", "playCount", default=0),
            "likes": field(it, "likesCount", "likeCount", default=0),
            "comments": field(it, "commentsCount", "commentCount", default=0),
            "caption": field(it, "caption", "text", default=""),
            "transcript": transcript,
            "status": "needs-analysis",
        })
        seen.add(code)
        new += 1

    date = datetime.date.today().isoformat()
    batch_path = STAGING / f"batch-{date}.json"
    write_json(batch_path, batch, indent=2, ensure_ascii=False)
    ledger["scraped"] = sorted(set(ledger["scraped"]) | {b["shortcode"] for b in batch})
    write_json(LEDGER, ledger, indent=2)

    print(f"\nstaged {len(batch)} new reels -> {batch_path.name}")
    print('next: tell Claude "process the latest batch in staging/ following ANALYZE.md"')


if __name__ == "__main__":
    main()
