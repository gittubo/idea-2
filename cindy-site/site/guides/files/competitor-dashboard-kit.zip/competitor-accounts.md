# Competitor accounts

The scraper reads every row where **Active = yes**. Exact Instagram usernames, no `@` needed. Start with 3 to 7 accounts, the ones whose audience you actually want.

Good picks: accounts your size or 1 to 2 tiers above you, posting reels consistently in your niche. Skip celebrities, their numbers don't tell you anything you can use.

| Username | Niche / why tracked | Size (rough) | Active |
| ---------------- | ------------------------------------ | ------------ | ------ |
| itsmariahbrunner | closest same-lane rival, AI for career + income | 159k | yes |
| sabrina_ramonov | AI tools + automated content systems | big | yes |
| jlee.mov | AI systems builds, small but outlier hooks | 2k | yes |

**Maintain it:** when an account goes quiet or drifts off-niche, flip it to `no` (don't delete the row, the history explains itself later). Add new finds as you spot them; the dashboard's reach-by-account view will tell you quickly who's worth keeping.
