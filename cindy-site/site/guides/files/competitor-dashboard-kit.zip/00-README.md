# The competitor dashboard (full setup guide)

Hey, it's Cindy 🤍 This is the system from the reel: run one script, and Claude rebuilds a dashboard of your competitors' latest reels. Who's posting, which hooks are pulling views, and the full script of every reel broken into Hook / Beats / CTA. You review your niche in about three minutes instead of scrolling for hours.

You're getting the whole thing:

| File | What it is |
|---|---|
| `00-README.md` | This guide, start here |
| `scrape.py` | The scraper. Pulls competitor reels + transcripts in ONE pass (the only code you run) |
| `ANALYZE.md` | The analysis playbook Claude follows to score + break down every reel |
| `DASHBOARD-SPEC.md` | The spec Claude follows to build your dashboard.html |
| `competitor-accounts.md` | Your competitor list, a template to fill in |

You don't need to be able to code. The fastest path is to hand this whole folder to Claude and let it do the setup.

## The 5-minute version (recommended)

1. Install [Claude Code](https://claude.com/claude-code) if you don't have it (the Code tab in Claude Desktop works too).
2. Make a folder (e.g. `competitor-dashboard/`), save all five files into it.
3. Open Claude Code in that folder and say:

> Read 00-README.md and set this competitor dashboard up for me. My niche is [what you make content about, and for whom]. My competitors are [3 to 7 Instagram handles]. Walk me through getting the one API key, then do the rest yourself.

Claude takes it from there, including editing the niche line in `ANALYZE.md` and filling `competitor-accounts.md` for you.

## The one key you need

This version needs ONE API key (the original systems like this float around with two or three, you don't need them):

- **Apify** does the scraping AND the transcription in a single pass, because its Instagram reel scraper has a built-in transcript add-on. Sign up at [apify.com](https://apify.com), then Settings, Integrations, copy your API token.

Put it in a `.env` file next to `scrape.py` (ask Claude to create it):

```
APIFY_TOKEN=your-apify-token
```

One hygiene rule: the key lives in `.env` in this folder, never in your shell profile and never pasted into chats. If this folder ever touches git, `.env` goes in `.gitignore` first.

## What it costs to run

- Scraping: fractions of a cent per reel.
- Transcripts: about 5 cents per minute of audio.
- The analysis and the dashboard: free, Claude does them in your normal session.

At 3 reels per account, a handful of accounts, a couple of runs a week, that lands around **$3 a month**, and Apify's free monthly credit covers most or all of it while you're testing.

## Manual setup (if you'd rather drive)

1. Fill in `competitor-accounts.md`, one row per competitor, `Active = yes` for the ones to track.
2. Open `ANALYZE.md` and replace the YOUR NICHE line at the top with what you actually make content about.
3. Run the scraper (needs Python 3.10+ and the `requests` package, `pip install requests`):

```bash
python3 scrape.py               # 3 latest reels per active account
python3 scrape.py --limit 5     # or 5 per account
python3 scrape.py --balance     # check your Apify spend/credit first
```

4. Tell Claude: "Process the latest batch in staging/ following ANALYZE.md." It scores every reel for relevance to your niche, splits the transcript into Hook / Beats / CTA, and writes one note per keeper into `notes/`.
5. Tell Claude: "Build the dashboard following DASHBOARD-SPEC.md." You get a `dashboard.html`, open it in your browser.
6. Repeat whenever you want fresh data: scrape, "process the batch", "rebuild the dashboard". The scraper remembers what it's already seen, so you only ever pay for new reels.

## The weekly rhythm

Run it once or twice a week. Open the dashboard, read the top hooks and the hook taxonomy (which hook styles keep winning in your niche), pick your angles. That's the whole point: you stop watching reels and start watching patterns.

## Fair-use notes (read this once)

- This is research signal, not a content-theft kit. You're studying what works (hooks, structures, topics), not republishing anyone's reels. Don't repost transcripts, and when a specific creator's reel inspires yours, credit them in the caption.
- Use your own Apify account and keep the volume reasonable (the defaults are). Scraping public Instagram data sits in a gray area of Instagram's terms, the same gray area every analytics tool lives in. Nothing here logs into Instagram or touches your own account.
- No videos are ever downloaded in this version, so there's nothing to clean up. Transcripts and notes are all that's stored.

## Troubleshooting

- **"APIFY_TOKEN not set"**: the `.env` file isn't next to `scrape.py` or the line inside it is missing. Ask Claude to fix it.
- **Scrape returns 0 items**: check the handles in `competitor-accounts.md` are exact Instagram usernames (no `@`), and marked `Active = yes`.
- **A transcript comes back empty**: some reels are music-only. They still stage; Claude scores them from the caption.
- Anything else: paste the error into Claude. It has all five files, it can fix its own plumbing.
