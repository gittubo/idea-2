#!/bin/zsh
# ---------------------------------------------------------------------
# jarvis_speak.sh  ·  say something out loud, in three tiers
#
#   1. Fish Audio  (your designed British voice)
#   2. edge-tts    (free neural fallback)
#   3. say         (built-in, always works)
#
# Usage:  ./jarvis_speak.sh "Good morning. Two meetings before noon."
#         ./jarvis_speak.sh --file brief.txt
#
# Setup:  put these in a .env file next to this script:
#           FISH_API_KEY=your-key-here
#           FISH_VOICE_ID=your-32-char-reference-id
#         then:  chmod +x jarvis_speak.sh
#
# Why three tiers: an assistant that sometimes says nothing feels broken
# in a way a slightly cheaper voice never does.
# ---------------------------------------------------------------------
set -u
HERE="${0:A:h}"
OUT="${JARVIS_OUT:-$HERE/brief.mp3}"

# --- read the text -----------------------------------------------------
if [ "${1:-}" = "--file" ]; then
  TEXT="$(cat "${2:?need a file}")"
else
  TEXT="${1:?usage: jarvis_speak.sh \"text\"  |  --file brief.txt}"
fi
[ -z "$TEXT" ] && { echo "nothing to say"; exit 1; }

# --- load .env (never hardcode a key in this file) ---------------------
[ -f "$HERE/.env" ] && set -a && . "$HERE/.env" && set +a

play() { afplay "$1" 2>/dev/null || open "$1"; }

# --- tier 1: Fish Audio ------------------------------------------------
if [ -n "${FISH_API_KEY:-}" ] && [ -n "${FISH_VOICE_ID:-}" ]; then
  code=$(curl -s -o "$OUT" -w "%{http_code}" \
    -X POST "https://api.fish.audio/v1/tts" \
    -H "Authorization: Bearer $FISH_API_KEY" \
    -H "Content-Type: application/json" \
    -H "model: s2.1-pro-free" \
    -d "$(python3 -c 'import json,sys; print(json.dumps({"text":sys.argv[1],"reference_id":sys.argv[2],"format":"mp3"}))' "$TEXT" "$FISH_VOICE_ID")")

  # Check the BYTES, not just the status. A 200 can still be a JSON error.
  if [ "$code" = "200" ] && file -b "$OUT" | grep -qiE "audio|mpeg|adts"; then
    echo "voice: fish-audio (s2.1-pro-free)"
    play "$OUT"; exit 0
  fi
  echo "voice: fish-audio failed (http $code), falling back" >&2
  rm -f "$OUT"
fi

# --- tier 2: edge-tts --------------------------------------------------
# python3 is not one program. Homebrew's usually shadows the system one,
# and only one of them has edge_tts installed. Find the right one.
EDGE_PY=""
for p in ${(f)"$(which -a python3 2>/dev/null)"} /usr/bin/python3; do
  [ -x "$p" ] || continue
  if "$p" -c "import edge_tts" 2>/dev/null; then EDGE_PY="$p"; break; fi
done

if [ -n "$EDGE_PY" ]; then
  "$EDGE_PY" -m edge_tts --voice en-GB-RyanNeural --rate=-4% \
             --text "$TEXT" --write-media "$OUT" >/dev/null 2>&1
  if [ $? -eq 0 ] && [ -s "$OUT" ]; then
    echo "voice: edge-tts fallback (en-GB-RyanNeural)"
    play "$OUT"; exit 0
  fi
  echo "voice: edge-tts failed, falling back" >&2
  rm -f "$OUT"
fi

# --- tier 3: the built-in voice ---------------------------------------
echo "voice: system say (last resort)"
say -v Daniel "$TEXT"
