# Jarvis starter kit

The dashboard from the reel, plus the backend pieces that make it actually know things.

Full guide: https://cindyzhu.com.au/guides/build-a-jarvis-that-briefs-you

---

## What's in here

| File | What it does |
|---|---|
| `jarvis-starter.html` | The dashboard. One file, no installs, no accounts. Open it and it animates. |
| `jarvis_data.js` | The live layer. Your skill rewrites this and the dashboard picks it up. |
| `SKILL.md` | The brain. Drop it in `~/.claude/skills/jarvis/` and say "brief me". |
| `jarvis_speak.sh` | Text to speech with three fallback tiers, so it never goes silent. |
| `serve.sh` | Serves the folder at localhost, which you need for anything beyond static. |

---

## The 10 minute version

**1. Look at it.** Double-click `jarvis-starter.html`. It runs immediately on sample data.

**2. Make it yours.** Open it in any text editor. Everything you edit is in the config block at the very top: your name, your city, the counters, the sentence in the middle. Save, refresh.

**3. Give it a brain.** Copy `SKILL.md` to `~/.claude/skills/jarvis/SKILL.md`. Edit the numbered list in the middle so it points at your sources. Then in Claude Code, say "brief me".

**4. Authorise your connectors.** This is the step nobody can do for you, and the step that turns a pretty screensaver into an assistant. Go to https://claude.ai/customize/connectors, connect one, test one read-only question, then add the next. Claude Code inherits whatever you authorise on the web, so you never set them up twice.

**5. Let the brief drive the dashboard.** Ask Claude Code to rewrite `jarvis_data.js` at the end of every brief run. Anything it sets there overrides the samples in the HTML, so you never touch the big file again.

**6. Give it a voice.** Put your Fish Audio key in a `.env` file next to `jarvis_speak.sh`:

```
FISH_API_KEY=your-key-here
FISH_VOICE_ID=your-32-character-reference-id
```

Then `chmod +x jarvis_speak.sh` and `./jarvis_speak.sh "Good morning."`

Never commit that `.env`. Add it to `.gitignore` first.

---

## Things that will bite you

**A connector says "needs auth" even after you reconnected it on the web.** The connection is fine. Claude Code caches auth state at `~/.claude/mcp-needs-auth-cache.json`. Back it up, delete the file, then fully quit and reopen Claude Code with Cmd+Q. Not just closing the window.

**A connector is missing entirely.** Run `/status`. Connectors only load when your active auth is a claude.ai subscription login. A stray `ANTHROPIC_API_KEY` in your shell profile hides every one of them, silently.

**Gmail and Google Calendar can't be added from the terminal.** They're Anthropic-hosted and only accept the redirect URL claude.ai registered. Connect them on the web.

**The voice is silent with no error.** Almost always `python3` resolving to an interpreter without `edge_tts` installed. `jarvis_speak.sh` already searches for the right one, which is why it's written the way it is.

**Nothing loads when you open the file directly.** `file://` pages get an opaque origin, so `fetch` is blocked and no server header fixes it. Run `./serve.sh` and use http://localhost:8787 instead.

---

## The one rule

Never let it write a number the run didn't actually retrieve. If a source was unreachable, mark it offline and say so. A dashboard that quietly shows stale numbers is worse than one that admits it's blind, because you stop being able to trust any of it.

Email stays drafts-only. Read before write. Nothing irreversible without you.
