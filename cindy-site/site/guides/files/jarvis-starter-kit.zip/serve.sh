#!/bin/zsh
# ---------------------------------------------------------------------
# serve.sh  ·  open the dashboard at localhost instead of file://
#
# Why this matters: from a file:// page the browser gives you an OPAQUE
# origin, so fetch() is blocked outright and no server header can fix it.
# http://localhost is treated as a secure context, so everything works.
#
# Usage:  ./serve.sh        then visit http://localhost:8787
# ---------------------------------------------------------------------
PORT="${1:-8787}"
HERE="${0:A:h}"
cd "$HERE" || exit 1
( sleep 1.2; open "http://localhost:$PORT/jarvis-starter.html" ) &
echo "Serving $HERE at http://localhost:$PORT  (ctrl-C to stop)"
python3 -m http.server "$PORT" --bind 127.0.0.1
