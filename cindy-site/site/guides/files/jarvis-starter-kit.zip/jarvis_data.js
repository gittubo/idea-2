/* ---------------------------------------------------------------------
   jarvis_data.js

   Your morning-brief skill REWRITES this file every time it runs.
   Anything set here overrides the sample values inside
   jarvis-starter.html, so that file stays untouched.

   The values below are samples. Delete them and let the skill take over,
   or hand this file to Claude Code and say "write this from my real data".

   Rule: never write a number the run didn't actually retrieve. If a
   source was unreachable, mark its service "off" and say so in the
   headline. A dashboard that quietly shows stale numbers is worse than
   one that admits it's blind.
   --------------------------------------------------------------------- */

window.JARVIS_DATA = {

  owner: "YOUR NAME // COMMAND CENTER",
  city:  "YOUR CITY",

  // The one human sentence on the page. Write it like you're being told
  // what today looks like. <b> lights the important part up.
  headline: "<b>3 things need you today.</b> Two meetings before noon, 4 emails waiting on a reply, and the thing you keep moving is now 6 days old.",

  hero: { value: 3, label: "NEED YOU TODAY" },

  stats: [
    { value: "2",  label: "MEETINGS"  },
    { value: "4",  label: "REPLIES"   },
    { value: "11", label: "UNREAD"    },
    { value: "6",  label: "TASKS"     },
    { value: "1",  label: "OVERDUE"   },
    { value: "3",  label: "PRIORITIES"}
  ],

  // Set state from whether the call ACTUALLY returned data.
  // "on" green, "warn" amber, "off" red, "live" pulsing.
  services: [
    { name: "CALENDAR",  note: "2 EVENTS TODAY",  state: "on"   },
    { name: "EMAIL",     note: "4 NEED A REPLY",  state: "on"   },
    { name: "TASK LIST", note: "6 OPEN",          state: "on"   },
    { name: "NOTES",     note: "NOT CONNECTED",   state: "warn" },
    { name: "WEATHER",   note: "SAMPLE DATA",     state: "on"   },
    { name: "CLOCK",     note: "YOUR SYSTEM CLOCK", state: "on" }
  ],

  // One line per source the run actually read.
  log: [
    "CALENDAR // 2 events read, next at 10:30",
    "GMAIL // 11 unread, 4 need a reply, 4 drafts written",
    "TASKS // 6 open, 1 overdue since Tuesday",
    "BRIEF // assembled, 47 seconds spoken"
  ],

  // The audio your speak script wrote. BRIEF ME plays this.
  briefAudio: "brief.mp3"
};
